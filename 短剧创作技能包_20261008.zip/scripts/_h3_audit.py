# -*- coding: utf-8 -*-
"""按官方 h3-prompt-writing 规范审计提示词。

用法：
    "C:/Users/86134/.workbuddy/binaries/python/envs/default/Scripts/python.exe" \
        _h3_audit.py xs900_segs/seg01_prompt.txt
    ... _h3_audit.py xs001_segs/seg02_prompt.txt

审计项来自官方规范 + 本项目三条铁律（否定词/对称词/中文变形）。
⛔ 校验器本身也会骗人 —— 上线前必须造已知答案样本先验证它自己。
"""
import io
import os
import re
import sys

# 官方：生成任务正文 350–500 英文词；官方跑酷范本（6刀+约束段）本身约 560 词
BODY_MIN, BODY_MAX = 350, 580
SECTIONS = ["subject_definitions:", "summary:", "retention_analysis:",
            "detailed_description:", "overall_soundscape:", "non_diegetic_music:"]

VISUAL_MARKERS = ["fully_preserved", "partially_preserved",
                  "attribute_transfer", "weak_reference"]
AUDIO_MARKERS = ["fully_copy", "partially_copy", "reference", "weak_reference"]

# 本项目三条铁律
# ⛔ 只抓「用否定句去禁止某物」这种**真正会诱发反向生成**的句式。
#    不抓 without heat / never leaves it / empty her pockets 这类
#    —— 它们是正常英文（不带怒气地、镜头不离开、掏空口袋），
#    误报会让人把正确的句子改坏，比漏报更危险。
BAD_NEGATION = re.compile(
    r"\bnobody\b|\bno one\b|\bno other\b|\bnot a single\b|"
    r"\bdoes not (?:show|contain|include|appear)\b|"
    r"\bduplicat(?:e|ed|ing|ion)\b|"
    r"\b(?:is|are|stays?|remains?) (?:completely |totally |absolutely )?empty\b|"
    r"\bhalf of (?:the )?frame\b|\beach one holding\b|"
    r"\bown third\b|\bthird of the frame\b|\bcentre axis\b|"
    r"\bfar half of\b|\bnear half of\b|\bleft half of\b|\bright half of\b",
    re.I)
# 文字变形：H3 画中文必变形，人物胸前不许有文字
BAD_TEXT = re.compile(r"badge|lanyard|name\s?tag|nametag|placard|sticker on|"
                      r"text on (?:her|his|their)|chinese characters|hanzi",
                      re.I)


def words(s):
    return [w for w in re.split(r"\s+", s.strip()) if w]


def audit(path):
    t = io.open(path, encoding="utf-8").read()
    ok, bad = [], []

    def chk(cond, good, why):
        # good 只用于 ok 列表的说明，why 是失败时打印的原因
        (ok if cond else bad).append("%s" % (why if cond else "!! " + why))

    # ── 结构 ───────────────────────────────────────────────
    pos = [(s, t.find(s)) for s in SECTIONS]
    chk(all(p >= 0 for _, p in pos), "六段齐全",
        "六段齐全 — 缺: %s" % [s for s, p in pos if p < 0])
    chk(pos == sorted(pos, key=lambda x: x[1]), "顺序正确", "六段顺序正确")

    # ── 字数（只算正文：detailed_description 到 overall_soundscape 之间，
    #        且**不含** detailed_description 之前的内容）
    if all(p >= 0 for _, p in pos):
        a = t.index("detailed_description:") + len("detailed_description:")
        b = t.index("overall_soundscape:")
        body = t[a:b]
        n = len(words(body))
        chk(BODY_MIN <= n <= BODY_MAX, "正文 %d 词" % n,
            "正文 %d 词在 %d-%d 内" % (n, BODY_MIN, BODY_MAX))
        # 总词数也要克制：正文 500 词 + 五段标签 ≈ 700-900 词。
        # 上一版 1287 词就是"动作被稀释 → 成片平庸"的根因。
        total = len(words(t))
        chk(total <= 1000, "总词数 %d" % total,
            "总词数 %d（官方建议正文 350-500，连标签整体不宜超 1000；"
            "上一版 1287 词导致动作被稀释、画面平庸）" % total)
    else:
        n = -1

    # ── 时间轴 ─────────────────────────────────────────────
    body_only = (t[t.find("detailed_description:"):]
                 if "detailed_description:" in t else t)
    shots = sorted(set(re.findall(r"\[Shot (\d+)\]", t)))
    chk(1 <= len(shots) <= 8, "镜头数 %d" % len(shots),
        "镜头 %s 个（官方跑酷范本 10秒6刀；>7刀每刀不足1.5秒会糊）"
        % (shots or "-"))
    # 官方每刀机位不同 —— 这是电影感的主要来源
    cams_all = re.findall(r"Camera:\s*([A-Z][a-zA-Z ]+?)(?: with|\.|,|$)",
                          body_only, re.M)
    if cams_all:
        uniq = len(set(c.strip() for c in cams_all))
        chk(uniq >= min(3, len(cams_all)), "机位多样 %d/%d" % (uniq, len(cams_all)),
            "机位 %d 种 / 共 %d 处（官方范本每刀机位都不同，重复机位=平）"
            % (uniq, len(cams_all)))

    first_shot = re.search(r"\[Shot 1\][^\n]{0,80}", body_only)
    chk(first_shot and "At 00:" not in first_shot.group(0), "Shot1 无时间戳",
        "[Shot 1] 不带时间戳")

    cuts = re.findall(r"At (\d\d:\d\d\.\d\d\d)(?!\d)", body_only)
    cuts = [c for c in cuts if re.match(r"^\d\d:\d\d\.\d\d\d$", c)]
    chk(cuts == sorted(cuts), "切点递增",
        "切点时间严格递增 %s" % (cuts or "-"))
    # 官方 S.SS 是「秒.百分之一秒」两位，写作 SSS 时是三位毫秒；
    # 两种都接受，只要 00:SS.mmm 里的 SS 是两位整数、mmm 是三位。
    chk(all(re.match(r"^\d\d:\d\d\.\d\d\d$", c) for c in cuts), "时间戳格式",
        "切点格式为 MM:SS.mmm %s" % (cuts or "-"))
    if cuts:
        def to_sec(c):
            _, rest = c.split(":")
            ss, ms = rest.split(".")
            return int(ss) + int(ms) / 1000.0
        secs = [to_sec(c) for c in cuts]
        chk(max(secs) < 10.0, "切点在时长内",
            "所有切点都在 10 秒内（最晚 %.1fs）" % max(secs))
    # 每个 Shot N>1 都必须带切点
    miss = [s for s in shots if s != "1"
            and not re.search(r"\[Shot %s\][^\n]{0,60}?At \d\d:\d\d\.\d\d\d" % s,
                               body_only)]
    chk(not miss, "每刀有切点",
        "Shot2+ 都带时间戳%s" % ("" if not miss else " — 缺: %s" % miss))

    # ── 运镜：官方两种写法都算 ──────────────────────────────
    #   写法A（旧）: "performs a Push In with small amplitude at slow speed"
    #   写法B（官方范本）: "Camera: Push In with small amplitude at slow speed"
    cams = re.findall(
        r"(?:performs a |Camera:\s*)([A-Z][a-zA-Z ]+?) with "
        r"(small|medium|large) amplitude(?: at (slow|medium|fast) speed)?",
        body_only)
    cams3 = [c for c in cams if c[2]]
    chk(len(cams) >= 1, "运镜 %d 处" % len(cams),
        "运镜写了 %d 处，其中写全速度的 %d 处（官方要求 类型+幅度+速度）"
        % (len(cams), len(cams3)))
    chk(len(cams) == len(cams3), "运镜速度齐全",
        "每处运镜都带速度 — 缺速度: %s"
        % [c[0].strip() for c in cams if not c[2]])
    # 运镜词必须出自官方 14 种词表
    OFFICIAL_CAMS = {
        "zoom in", "zoom out", "push in", "pull out", "pan left", "pan right",
        "truck left", "truck right", "tilt up", "tilt down", "pedestal up",
        "pedestal down", "arc shot", "tracking shot", "static shot",
        "shake slightly", "shake strongly", "pov", "roll clockwise",
        "roll counterclockwise",
        # morphic 官方指南「Name the transitions」明确点名：
        # "A wipe, a hard cut, a whip pan, a match cut on a shape"
        # → whip pan / whip pan left / whip pan right 是官方认可的转场写法，
        #    不在 14 种机位表里但同样有效（切镜更快时尤其常用）。
        "whip pan", "whip pan left", "whip pan right", "whip pan up",
        "whip pan down"}
    bad_cam = [c[0].strip() for c in cams
               if c[0].strip().lower() not in OFFICIAL_CAMS]
    chk(not bad_cam, "运镜用官方词",
        "运镜全部出自官方 14 种词表%s"
        % ("" if not bad_cam else " — 不在词表: %s" % bad_cam))

    # ── retention ─────────────────────────────────────────
    if "retention_analysis:" in t:
        ra = t[t.index("retention_analysis:"):t.index("detailed_description:")]
        has_visual = [m for m in VISUAL_MARKERS if m in ra]
        chk(bool(has_visual), "保留标记",
            "retention 用视觉标记 %s" % (has_visual or "无"))
        chk(not re.search(r"\(S\d\)", ra), "retention 无说话人编号",
            "retention_analysis 内无 (Sx) 编号（官方要求）")
        # 每个 Subject 都得有一行
        for s in sorted(set(re.findall(r"<Subject \d>", ra))):
            chk(ra.count(s) >= 1, "%s 有保留声明" % s,
                "%s 在 retention 里有声明" % s)

    # ── 声音 ──────────────────────────────────────────────
    m = re.search(r"non_diegetic_music:\s*(\S+)", t)
    chk(bool(m) and (m.group(1) == "N/A" or len(words(t[t.index("non_diegetic_music:"):])) > 5),
        "配乐字段",
        "non_diegetic_music = %s（不要配乐就写 N/A）"
        % (m.group(1) if m else "缺失"))

    # ── 台词 ──────────────────────────────────────────────
    chk(not re.search(r"[\"“][^\"”]*\[(Chinese|English)\]", t), "台词未加引号",
        "台词没被引号包（引号=画面上看得见的文字，包了会烧字幕）")

    # ── 本项目三条铁律 ────────────────────────────────────
    # 否定/对称词：**正文里**禁止；结尾「约束段」里官方范本明确鼓励写
    # （官方跑酷示例：No slow-motion, wire rigs, ... duplicated runners, distorted limbs）
    guard_start = body_only.find("No ") if "No " in body_only else len(body_only)
    # 约束段只到下一个字段为止（后面还有 overall_soundscape / non_diegetic_music）
    guard_txt = body_only[guard_start:]
    for field in ("overall_soundscape:", "non_diegetic_music:"):
        if field in guard_txt:
            guard_txt = guard_txt[:guard_txt.index(field)]
    body_main = body_only[:guard_start]
    h1 = sorted(set(m.group(0) for m in BAD_NEGATION.finditer(body_main)))
    chk(not h1, "正文零否定/对称词", "正文无泛用否定句与对称占比词%s"
        % ("" if not h1 else " — 命中: %s" % h1))

    # ── 官方范本：结尾一段「具体风险」约束句是**被鼓励的** ──
    # 官方跑酷示例原文就有 "No slow-motion, wire rigs, ... duplicated runners, distorted limbs"
    # 规则：正面描述为主体 + 结尾 ≤2 句、且每条都可观测（字幕/水印/多余人/变形/慢动作）
    # ⛔ 仍禁止「用否定句代替正面描述」：泛用负面词（no bad quality/ugly/blurry）
    chk(not re.search(r"\b(?:bad|low)\s+(?:quality|resolution)\b|\bugly\b|"
                      r"\bblurry\b|\bdeformed\b|\blowres\b", t, re.I),
        "无泛用负面词",
        "无泛用负面词（no bad quality/ugly/blurry 这类模型无法观测）")
    # 上面已把 guard_txt 截断到下一个字段为止（不要用未截断的原文重取）
    n_sent = len([s for s in re.split(r"\.", guard_txt) if s.strip()])
    chk(not guard_txt or (n_sent <= 2 and len(words(guard_txt)) <= 200),
        "约束段规范",
        "结尾约束段 %d 句 / %d 词（官方范本范式：正面为主体 + 一条逗号列出的具体风险否定）"
        % (n_sent, len(words(guard_txt))))
    h2 = sorted(set(m.group(0) for m in BAD_TEXT.finditer(t)))
    chk(not h2, "胸前无文字", "无胸牌/文字类元素%s"
        % ("" if not h2 else " — 命中: %s" % h2))

    print("=" * 66)
    print(" H3 提示词审计: %s" % path)
    print("=" * 66)
    for line in ok:
        print("  [ok]   %s" % line)
    for line in bad:
        print("  [!!]   %s" % line)
    print("-" * 66)
    print(" 通过 %d 项 / 失败 %d 项" % (len(ok), len(bad)))
    return len(bad)


if __name__ == "__main__":
    rc = 0
    for p in sys.argv[1:]:
        rc |= audit(p)
        print()
    sys.exit(1 if rc else 0)
