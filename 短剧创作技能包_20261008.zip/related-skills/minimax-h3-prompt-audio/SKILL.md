---
name: minimax-h3-prompt-audio
description: 让 MiniMax H3 视频里的人物「说人话 / 唱对词」——诊断并修掉人声含混、"Sims 语"、听不懂说了什么、说的是外语而不是中文、唱词对不上等问题。核心是 H3 的对话语法：说话人要用稳定编号 (S1)/(S2)，真正要说/唱的词句必须放进 [语言] 标签（如 [Chinese] 这一刻，我们一起发光。），并且提示词里绝不能出现"no intelligible words / 不要唱出能听懂的词"这类反向要求。当用户说「H3 视频里的声音不对」「说话听不懂」「不像中文」「人物说话含混」「唱的歌词对不上」「要不要在提示词里写说话内容」「口型对不上」时使用。
agent_created: true
---

# MiniMax H3 音频 / 人声提示词

H3 是**视频+音频联合生成**（一次出画面和声音），不是事后配音。所以声音效果**完全由提示词决定**，
没有单独的"音频提示词"输入框。声音不对 = 提示词里没写清楚。

## 一、先查这三件事（按命中率排序）

### 1. ⚠️ 提示词里有没有"反向要求"

最常见、也最容易被忽略的原因。很多从别处抄来的模板会写：

- `Her mouth movements naturally follow the vocal melody, but no intelligible lyrics are heard.`
- `Her live vocal is an energetic melodic performance without intelligible words.`
- 中文版：`嘴型跟着旋律动，但听不清唱的是什么`

**模型会严格照做**，于是产出"口型在动但全是含混人声 / 偶尔蹦两个词"的效果 —— 用户描述的
"说的不是中文、听不懂"正是这个。

→ 搜关键词 `no intelligible`、`without intelligible`、`unintelligible`、`听不清`、`含混`，
整句删掉或改写成"用中文清晰唱出某句歌词"。

### 2. 有没有写出**具体的词**

只说"她在唱歌"没用。必须把**原文**写进去，并用 `[语言]` 标签包起来。

### 3. 有没有给说话人**编号和音色**

不给编号，模型可能把话分给错的人，或者干脆当成环境杂音。

## 二、官方语法（照抄即可）

### 2.1 说话 / 唱歌的人：稳定编号 `(S1)`

- 说话人写 `(S1)`、`(S2)`，**跨镜头保持不变**；两人合唱/齐说用 `(S1,S2)`。
- 首次出现要让模型能区分这个人：**年龄、性别、音高、音色、口音**。
- 不想让某人说话，要**明说他在闭嘴**，否则模型会自己加台词。

### 2.2 真正的词句：`[语言] 原文`

格式是：**说话人的短语 + 编号 + 动作 + 语气（都在标签外）+ 冒号 + `[语言]` + 原文**。

```
the man with a low, steady voice (S1) says: [English] I get off at the next station.
the singing woman (S1) sings in a clear, bright youthful pop voice: [Chinese] 这一刻，我们一起发光。
```

铁律：

| 规则 | 说明 |
|---|---|
| 标签内**只放**语言标签 + 原文 + 标点 | 不要翻译、不要改写、不要截断 |
| **歌词/台词绝对不要用引号包** | 引号在 H3 里是留给"画面上看得见的文字"（招牌、字幕）的，用引号会让它把字烧进画面 |
| 听不清的地方写 `[unclear]` | 别自己猜一个词填进去 |
| 一句话跨镜头 | 两个镜头都要写 `[Chinese] ...`，并说明音频跨剪辑连续 |
| 被视频结束打断 | 用 `[cutoff]` |
| 语速预算 | **约 2.5 字/秒**。10 秒 ≈ 25 个汉字，别贪多 |
| 画外音 | 写 `says in an off-screen voiceover`，并紧跟一句"画面里的人物嘴是闭着的" |

### 2.3 唱歌属于"画面内声音"，写进描述里

`overall_soundscape` 只放**环境音和物理音**（观众欢呼、脚步、麦克风摩擦声）。
**唱歌、场景里的收音机、街头艺人属于 diegetic（画面内）**，要写进带时间线的正文描述里。
放错地方声音就出不来或变味。

### 2.4 不想要配乐就写 `non_diegetic_music: N/A`

留空或写得含糊，模型会自己加一段你没要的音乐。这是社区里最常引用的一个修复。

## 三、参考图/参考音模式（ref2v）的固定六段结构

用参考素材时，提示词必须按这个顺序，缺段会漂移：

```
subject_definitions:      # <Subject 1> 是什么，特征；<Picture i>/<Video k>/<Audio j> 各干什么活
summary:                  # 以 [reference generation] 这类方括号任务前缀开头，一句话说清要生成什么
retention_analysis:       # 每个标签给一个标记：fully_preserved / partially_preserved / attribute_transfer / weak_reference（画面），
                          #                               fully_copy / partially_copy / reference / weak_reference（声音）
detailed_description:     # 主要战场。[Shot 1] / At 00:03.500, the camera cuts to ... 350~500 词。台词全写这里
overall_soundscape:       # 环境音 + 物理音
non_diegetic_music:       # 配乐，或 N/A
```

- 标签：`<Picture i>` / `<Video k>` / `<Audio j>`，**每种类型各自从 1 开始编号**；
  同一个参考视频的音轨单独算一个 `<Audio j>`，编号在它对应的 `<Video k>` 之前。
- 第一个镜头**不带时间戳**，之后的镜头开头必须是严格递增的切点时间 `At 00:04.500, the camera cuts to ...`。
- 台词多的时候可以超字数，但生成任务正文常规是 350~500 英文词。
- 想固定音色：用 `ref_audio_*` 槽位喂一段参考音频，标签 `<Audio j>`，
  在 `retention_analysis` 里写 `<Audio j> (S1 voice): reference, timbre only, no copied words`。

## 四、症状 → 修法速查

| 症状 | 提示词里的原因 | 修法 |
|---|---|---|
| 含混人声 / "Sims 语" / 听不懂 | 台词没结构、没编号，或没说话的人没说明在闭嘴 | 加 `(S1)` 编号；原文放进 `[Chinese] ...`；明说其他人不说话 |
| 说的是外语、不像中文 | 没指定语言，模型默认往英文跑 | 语言标签写 `[Chinese]`，并在描述里写"标准普通话发音/声调" |
| 画面被烧上字幕 | 台词被引号包住了 | 台词从引号里拿出来，放进 `[语言]` 标签 |
| 话分给了错的人 | 编号没跟具体的人绑 | 首次出现时给说话人年龄/性别/音色/口音，编号跨镜头稳定 |
| 冒出没要的配乐 | `non_diegetic_music` 空着 | 写 `non_diegetic_music: N/A` |
| 台词赶得听不清 | 词太多，超了 2.5 字/秒 | 缩短台词，或拉长时长 |
| 演唱/画面内收音不对 | 写进了 `overall_soundscape` | 移到带时间线的正文描述里 |

## 五、批量修已有工作流（本机做法）

提示词在节点 `PrimitiveStringMultiline`（本机是 node 1）的 `widgets_values[0]` 里。
同一个工作流一般有 3 份副本（`C:\Users\86134\Downloads\` + 两套 ComfyUI 的
`user\default\workflows\`），**三份都要改**。

可复用脚本：本机 `upg\fix_prompt_speech.py`（顶部常量就是要唱的歌词）。

要点：
- 先 `shutil.copy2` 出 `.bak_before_voice` 再写。
- 写回时 `json.dump(..., ensure_ascii=False, indent=2)`，**保持原文件的 2 空格缩进**，
  否则整个文件被压成一行，diff 全乱。
- **脚本要可反复执行**：用"原句 → 新句"的二分判断 + 正则替换歌词部分，
  避免第二次跑把补丁叠上去。
- 改完必须验证「除提示词外完全一致」：把两个版本的提示词字段换成占位符后整体比对，
  并核对 `last_node_id` / `last_link_id` 没变。

## 六、别做的事

- 不要指望"加个负面提示词"解决 —— **H3 是 CFG 蒸馏的，没有负面提示词**，提示词是唯一的控制杆。
- 不要把大段抽象的形容词（"震撼""有感染力"）当成音频描述，模型渲染不出看不见听不着的东西。
  要写可观测的：音高、音色、口音、语速、具体台词。
- 官方在模型仓库里带了一份提示词写作指南（`MiniMax-AI/MiniMax-H3` 的 `h3-prompt-writing` skill），
  遇到拿不准的结构先去查那份，别凭感觉编。
