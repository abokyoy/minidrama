---
name: minimax-h3-prompt-guide
description: MiniMax-H3 官方提示词写作规范与完整模板库。当需要为 H3 写/改/审提示词，尤其是参考图模式（Ref2VA）、运镜描述、台词与声音标签、音效与配乐字段、镜头时间轴时使用。覆盖六段式结构、四类标签、保留标记词表、运镜幅度/速度写法、10秒多镜头配方、常见失败症状对照表。关键词：H3 提示词、Ref2VA、subject_definitions、retention_analysis、fully_preserved、运镜、镜头时间轴、非叙事配乐。
agent_created: true
---

# MiniMax-H3 提示词写作规范（据官方 h3-prompt-writing 指南整理）

⚠️ **最常见的致命错误：把六段式结构写超长**。生成任务的正文
（`detailed_description`）**只写 350–500 英文词**。我曾写 1287 词 →
画面塞不下、动作被稀释、运镜被挤没 → **成片平庸**。

⚠️⚠️ **第二大错误：只读规范，不读官方示例**。官方跑酷示例
（Category 3 Rooftop Chase）是 10 秒 6 刀 + 每刀独立机位 + 每刀时间戳 +
结尾一大段约束句。我只读规范就自己写，结果又窄又 dull。
**写任何打斗/追逐前，先把下面的「官方跑酷示例原文」读一遍。**

## ⭐ 零、官方示例原文（打斗/追逐类必读范本）

来源：earngenix.com 收录的官方 Category 3 Rooftop Chase，标注
「Prompt structure verified against MiniMax H3's official prompting specification」。
**这是官方示例原样，10 秒 6 刀，照抄结构**：

```
integrated_multimodal_description: Live-action, cinematic rooftop action
sequence, high-contrast daylight, slightly desaturated palette, realistic
handheld texture and subtle 35mm grain — keep the gritty color grade, natural
lighting, runner identity, clothing, and realistic motion consistent
throughout.

[Shot 1] A wide establishing shot shows the runner sprinting toward the
rooftop edge with the city and large drop visible below. Camera: Static Shot,
holding the tension before the jump.

[Shot 2] At 00:01.300, hard cut to a low side angle following the runner's
feet as they accelerate toward the gap. Camera: Tracking Shot at fast speed
with slight handheld movement.

[Shot 3] At 00:02.600, hard cut to a dynamic side view as the runner launches
across the gap between buildings, legs fully extended in mid-air. Camera: Arc
Shot at fast speed, sweeping alongside the jump.

[Shot 4] At 00:04.100, hard cut to a tight close-up of the runner's face during
the jump, focused and straining while wind pushes against their clothing.
Camera: Push In with small amplitude at fast speed.

[Shot 5] At 00:05.800, hard cut to a low rooftop angle as the runner reaches the
opposite ledge and lands hard, immediately transitioning into a forward roll.
Camera: Tracking Shot at fast speed, following the landing and roll.

[Shot 6] At 00:07.300, hard cut to a wide rear angle as the runner quickly gets
back up and continues sprinting across the rooftop toward the next obstacle.
Camera: Pull Out with large amplitude at fast speed, revealing the surrounding
rooftops and city.

No slow-motion, wire rigs, visible harnesses, supernatural movement, impossible
physics, additional bystanders, duplicated runners, distorted limbs, floating
objects, excessive camera shake, soft dissolves, fades, or unnecessary
transitions; use hard cuts only and no on-screen text, logos, subtitles, or
watermarks.

overall_soundscape: Strong rooftop wind throughout, with rapid footsteps
approaching the edge, a sharp breath at 2.6s, clothing snapping during the jump,
and a heavy foot impact followed by a brief rooftop scrape at 5.8s.

non_diegetic_music: A low tense drone begins at 0s, fast electronic percussion
enters at 2s, the rhythm intensifies during the jump, and the music cuts sharply
at 5.8s on the landing before a low pulse returns for the final sprint.
```

### 从官方示例提炼出的六条（我此前全部没做到）
1. **10 秒 6 刀**，不是 3 刀。每刀 1.3–2 秒，但**每刀都只做一个明确动作**。
   我以为「3 刀不糊」——错，**刀多是允许的，糊是因为每刀塞太多动作**。
2. **每刀都写机位**，且机位**各不相同**（Static → Tracking → Arc → Push In →
   Tracking → Pull Out）。官方运镜词表见下节。
3. **风格句在第一刀里，且带"全程保持一致"的约束**：
   `keep the gritty color grade, natural lighting, runner identity, clothing,
   and realistic motion consistent throughout`
4. **结尾一整段约束句**，针对**这个镜头真实会出问题的地方**逐条点名。
5. **音效写到毫秒级时间点**：`a sharp breath at 2.6s`、
   `a heavy foot impact ... at 5.8s`。
6. **配乐有结构，不是一句「N/A」或「tense music」**：
   `drone@0s → percussion@2s → 节奏加强 → 5.8s 骤停 → 低频脉冲回归`。

### ⭐ 否定句：官方在用，我此前的「零否定词」铁律是错的
多个独立来源与官方示例一致：

| 来源 | 原文 |
|---|---|
| morphic | "**Write the negatives explicitly.** No subtitles, no watermarks... constraints are followed when they are stated." |
| earngenix（官方示例） | `No slow-motion, wire rigs, visible harnesses, ... duplicated runners, distorted limbs` |
| seedance | "Describe first, then add **one or two concrete 'No…' sentences tied to the actual risk**." |
| segmind（10次实测） | "Give it a sentence and it will **happily invent a whole commercial around you, with cuts you never asked for**." |

**要分清两件事**：

- H3 是 **CFG-distilled**，ComfyUI 里**没有单独的 negative 输入框**
  → 社区节点显示的 negative 框若没接进 guider/sampler，**写了也是摆设**
- ⛔ **但否定句写进主提示词是有效的** → 官方示例大量在用

**正确写法**（本项目据此修正）：

1. **先正面描述你要什么**（这是主体，占绝大多数篇幅）
2. **再补 1–2 句针对「本镜头真实风险」的否定**，
   每条都能在成片里被观测到，且**只写具体的**：

| ⛔ 无效写法 | ✅ 官方式有效写法 |
|---|---|
| `no bad quality, ugly, blurry`（泛用负面词，模型无法观测） | `no on-screen text, logos, subtitles, or watermarks` |
| 罗列 20 个通病 | `no duplicated runners, distorted limbs, floating objects`（只点这个镜头会出的） |
| `no extra people`（没说清什么算「人」） | `exactly one person is visible for the entire shot` |

**本项目三条铁律据此修正为**：
- **禁止的是「用否定句代替正面描述」**（写 `no badge` 却不说清胸前该是什么 → 反而强化 badge）
- **鼓励的是「正面描述写足 + 结尾补 1–2 句具体风险否定」**（官方跑酷示例范本）
- 否定句要**可观测**：字幕、水印、多余的人、变形肢体、慢动作、软溶解转场。

## 一、先选模式（选错就全白写）

| 模式 | 输入 | 结构 |
|---|---|---|
| T2VA | 纯文本 | 基础结构 |
| I2VA | 首帧图 | 基础结构 + 首帧对齐指令 |
| FL2VA | 首帧+尾帧 | 基础结构 + 对齐指令 |
| L2VA | 尾帧 | 基础结构 + 对齐指令 |
| **Ref2VA** | **参考图/视频/音频** | **六段式结构** |

对齐指令写法（I2VA/FL2VA/L2VA）：**必须是第一行，后面空一行**。
`The supplied image is the first frame at 00:00. Preserve identity, clothing,
composition, and lighting.`
T2VA 没有这一行。

## 二、基础结构（T2VA / I2VA / FL2VA / L2VA）

```
integrated_multimodal_description:
[Shot 1] {initial composition}. {subject action}.
[Shot 2] At 00:04.000, {new visual information}.
overall_soundscape: {ambience + physical sounds}
non_diegetic_music: {instrumentation + tempo + dynamics}; or N/A
```

## 三、Ref2VA 六段式结构（顺序固定，一个都不能少）

```
subject_definitions:      # 每个标签是什么
summary:                  # 一段话：任务类型 + 目标视频 + 主参考关系
retention_analysis:       # 每个标签一行，写保留标记
detailed_description:     # 时间轴正文，350–500 词，台词写这里
overall_soundscape:       # 环境音 + 物理音
non_diegetic_music:       # 或 N/A
```

### subject_definitions 的关键区分
**`<Subject N>` 是内容，`<Picture N>/<Video N>/<Audio N>` 是素材。**

- 只定义人物长相的图**不给它独立一行**，在人物定义里引它：
  `<Subject 1> is the young woman in <Picture 1>, with long dark hair and a blue cardigan.`
- 图本身就是画面锚点时才单独一行：
  `<Picture 1> is the first frame of [Shot 1], showing a woman seated beside a café window.`

标签一旦定义，**每段含义必须一致**。`subject_definitions` 之后不得引入新标签，
也不得有标签没被解析。

### summary 的任务类型前缀（方括号）
可组合，用 `+` 连接：`[reference generation + audio reference]`

| 任务类型 | 什么时候用 |
|---|---|
| `keyframe completion` | 图是输出的具体某帧 |
| `reference generation` | 素材引导人物/场景/风格/动作/运镜 |
| `video editing` | 直接改现成视频 |
| `video continuation` | 续接已有视频 |
| `audio reuse` | 复用同一段音频信号 |
| `audio reference` | 只参考音色/内容/质感/节拍 |

- summary **只写任务关系，不写剧情摘要**。
- 只提供运镜的参考视频 = `reference generation`，**不是** `video editing`。
- `video editing` 必须以 `The target video is an edited version of <Video 1>.` 开头。

### retention_analysis 保留标记词表
视觉（`<Subject>/<Picture>/<Video>`）：

| 标记 | 含义 |
|---|---|
| `fully_preserved` | 完全保留 |
| `partially_preserved` | 某个**已定义的**特征变了 |
| `attribute_transfer` | 只取属性 |
| `weak_reference` | 弱参考 |

音频（`<Audio>`）：

| 标记 | 含义 |
|---|---|
| `fully_copy` | 完全复制 |
| `partially_copy` | 部分复制 |
| `reference` | 只参考（音色等） |
| `weak_reference` | 弱参考 |

格式：`<Subject 1> (appears in [Shot 1], [Shot 3]): fully_preserved -
her long dark hair and blue cardigan are retained.`

⛔ `retention_analysis` 里**不能出现 (S1) 这类说话人编号**。

## 四、时间轴语法

- `[Shot 1]` **不带时间戳**。
- 之后每个切点：`[Shot N] At 00:SS.mmm, {切什么 + 新信息}`。
- `S.SS` 严格**两位小数**（如 `00:04.500`）。
- 切点时间**严格递增**，且**必须在请求时长内**。
- 每个切点必须引入**新的人物/空间/状态/视角/时间信息**。
- **微调构图用运镜，不要新增镜头**（否则镜头数爆炸、每个都糊）。
- `[Shot N]` 的 N 要是**最终真实镜头序号**。
- 台词带 `[cutoff]` 用于被结尾打断；跨镜头台词两个镜头都要写并说明音频跨剪辑连续。

## 五、对话语法

```
说话人身份 + (S1) + says/sings: [Chinese] 原句
```
- 编号跨镜头稳定；**首次出现**给年龄/性别/音高/音色/口音。
- **不说话的人要明说他闭嘴**，否则模型自己加台词。
- 语速 **约 2.5 字/秒**，10 秒 ≈ 25 汉字，别贪多。
- **台词绝不能用引号包** → 引号是留给画面上看得见的文字的，一包就把字烧进画面。
- 标签内只有语言标签 + 原句 + 标点，不翻译不改写。

### ⭐⭐ `(S1)` 与 `<Subject 1>` 是两套独立体系（最容易踩）
官方实测指南原文：

> **CRITICAL: S1 does NOT equal Subject 1!**
> `<Subject N>` = 视觉主体/素材标签（在 `subject_definitions` 里定义）
> `(S1)` = **声音来源编号**，按**时间线上第一次发声的顺序**分配
> **不发声的角色根本不分配 `(Sx)`**

| 规则 | 说明 |
|---|---|
| 编号按发声顺序**连号** | 第一个开口=S1，第二个=S2。**不要跳号**（S1/S3/S4 会让模型困惑「S2 是谁」） |
| 主体标签必须出现在正文 | 正文只写「苏小满 (S1)」而没有 `<Subject 2>` → 模型没有主体可绑定 → 身份漂移 |
| 推荐写法 | 正文每处人物都带 `<Subject N>`；说话人另标 `(Sx)` |
| 主说话人排第一 | 多主体镜头里**正在说话的人必须在 `subject_definitions` 排第一**，否则台词绑到别人脸上 |
| 单人镜头要隔离他人 | 显式写 `<Subject 3> is not in frame`，不要靠省略标签 |
| 交接镜头三件套 | 继承静默拍（明说 `mouth closed, speaking no dialogue`）→ 运镜带人出画 → 新说话人开口 |

### 无台词场景要主动消音（实测高频问题）
非对话场景、或角色在画面里但别人说话时，H3 常见**人物莫名嘟囔/嘴唇乱动**。
→ 明写：`Both remain completely silent with their mouths closed, speaking no dialogue.`

## 六、声音分工（放错位置就出不来）

| 字段 | 装什么 |
|---|---|
| `detailed_description` | **画面内声音**：台词、唱歌、场景里的收音机、街艺人 |
| `overall_soundscape` | 环境音 + 物理音（脚步、衣料、观众、风） |
| `non_diegetic_music` | 只给观众听的配乐：**乐器 + 速度 + 动态**；不要就写 `N/A` |

⛔ 画面内声音放进 `overall_soundscape` 就出不来/变味。
⛔ `non_diegetic_music` 留空或含糊 → 模型自己加一段你没要的音乐。
**`non_diegetic_music: N/A` 是社区公认的杀配乐修法。**

## 七、运镜写法（官方 14 种机位词表）

必须写 **机位类型 + 幅度 + 速度**，写成自然英文句子，不是标签：

```
The camera pushes in with small amplitude at slow speed toward the folded letter in her hands.
The camera pans right with large amplitude at fast speed, revealing the open doorway.
```

### 官方完整词表（按运动方式分类）

| 类型 | 含义 | 原词 |
|---|---|---|
| 变焦（机位不动） | 改焦距 | `Zoom In` / `Zoom Out` |
| 推轨（机身动） | 前后移动 | `Push In` / `Pull Out` |
| 摇（原地转） | 水平 | `Pan Left` / `Pan Right` |
| 横移（机身平移） | 水平 | `Truck Left` / `Truck Right` |
| 俯仰（原地转） | 垂直 | `Tilt Up` / `Tilt Down` |
| 升降（整机升降） | 垂直 | `Pedestal Up` / `Pedestal Down` |
| 环绕 | 绕主体 | `Arc Shot` |
| 跟随 | 跟拍移动主体 | `Tracking Shot` |
| 固定 | 不动 | `Static Shot` |
| 抖动 | 晃 | `Shake Slightly` / `Shake Strongly` |
| 主观视角 | 角色视角 | `POV` |
| 滚转 | 镜头滚转 | `Roll Clockwise` / `Roll Counterclockwise` |

- 幅度：`with small amplitude` / `with large amplitude`（中幅度一般省略）
- 速度：`at slow speed` / `at fast speed`（正常速度一般省略）
- ⛔ 只罗列 `dolly, orbit, handheld, zoom` 而不写先后 = 顺序没定义 = 模型随便挑。
- **官方示例里每刀机位都不同**，这是「电影感」的主要来源，不要全片重复一个机位。

### 打斗/动作片的机位配比经验
官方跑酷 6 刀用了：Static → Tracking → Arc → Push In → Tracking → Pull Out。
规律：**远景交代空间（Static/Pull Out）→ 中景跟动作（Tracking/Arc）→ 近景给情绪（Push In）**。

## 八、风格句

`detailed_description` 在 `[Shot 1]` **之前**放 1–2 句整体视觉风格。
⛔ 抽象情绪词（"epic" "震撼" "有感染力"）**官方明确不建议**——
模型渲染不出看不见听不着的东西。写可观测的：光位、材质、色温、景深、镜头焦段。

## 九、Final audit checklist（写完必查）

- [ ] 模式选对了吗（六段式 vs 基础结构）
- [ ] 六段齐全且顺序正确
- [ ] 每个标签只定义一次，全文含义一致，无未解析标签
- [ ] summary 任务前缀与实际素材角色匹配，且没引入新标签
- [ ] `retention_analysis` 标记用对了，且无 `(Sx)` 编号
- [ ] 风格句在 `[Shot 1]` 之前
- [ ] 每个标签都在时间轴里被引用到
- [ ] `[Shot 1]` 无时间戳，之后切点严格递增、两位小数、在时长内
- [ ] 每个切点都带来新信息；微调用运镜没开新镜头
- [ ] 说话人编号跨镜头稳定，不说话的人已明说闭嘴
- [ ] 台词没被引号包
- [ ] 画面内声音在 `detailed_description`，`overall_soundscape` 只有环境音物理音
- [ ] `non_diegetic_music` 写了「乐器+速度+动态」或 `N/A`
- [ ] **正文 350–500 词**（不是 1287 词）
- [ ] 已删掉所有互相打架的运镜/切换/换身份/换声音指令

## 十、症状 → 修法

| 症状 | 提示词原因 | 修法 |
|---|---|---|
| 画面平庸/动作糊成一团 | 正文超长超 500 词 | 砍到 350–500 |
| 运镜乱跳 | 罗列机位没写顺序 | 逐镜写机位+幅度+速度 |
| 「Sims 语」/听不懂 | 无编号、原文没进标签 | 加 `(S1)` + `[Chinese] 原句` + 明说不说话的人闭嘴 |
| 画面烧字幕 | 台词被引号包了 | 台词拿出引号 |
| 冒出没要的配乐 | `non_diegetic_music` 空着 | 写 `N/A` |
| 人物/服装/产品漂移 | 没声明角色 | `retention_analysis` 写 `fully_preserved`，并在每次出场重复标签 |
| 莫名切镜头 | 场景变了但没时间戳 | 每刀都给 `[Shot N] At 00:0X.000` |
| 抽象词不起作用 | 写了 epic/震撼 | 换成可观测描述 |

## 十一、10 秒多镜头配方（Ref2VA 打斗/特效类）

- **不要 5 刀**。10 秒 3 刀最稳，每刀 3 秒左右。
- 每刀一个**明确可测的成品目标**（能逐帧核对的那种）。
- 参考图一人一张，**一人只干一件事**（身份），别让图去管场景。
- 特效写成**具体物理形态**（"两指宽的青色光刃" > "强大的剑气"），
  抽象的"强大特效"模型渲不出来。
- 打斗要有**明确的起手-交锋-收势三段**，中间那刀才是高潮。
- 想固定脸 → 参考图 + `fully_preserved` + **每次出场都重复 `<Subject 1>`**。

## 十二、真实翻车记录（2026-10-08，必读）

修仙测试段第一版**效果平庸**，自查后找到根因，**不是模型不行，是提示词超长**。

| 项 | 错误写法 | 官方要求 | 后果 |
|---|---|---|---|
| 正文词数 | **1287 词** | **350–500 词** | **动作被稀释，每个动作只够画1.5帧 → 全糊** |
| 镜头数 | 5 个 Beat 挤 10 秒 | 3 刀，每刀 3 秒 | 每刀 2 秒，来不及起势 |
| 运镜 | `the camera follows her up` | `performs a Tilt Up with small amplitude at slow speed` | 模型自己挑运镜，动线乱 |
| 摘要 | 写成一整段剧情 | 1 段任务类型+目标 | 权重被摘要吃掉 |
| 保留声明 | `face fully preserved` 自造写法 | `fully_preserved - 具体特征` | 模型认不出标记语义 |

**改后**：正文 500 词 / 3 刀 / 运镜全写全 → **20 项审计 0 失败**。

### 教训
1. **超长提示词是最隐蔽的失败原因**。写之前先数字数，别写完再想。
2. 「效果平庸」≠模型能力不行。先查字数、刀数、运镜写法，再怀疑模型。
3. 自造标记词（如 `face fully preserved`）模型认不出，**必须用官方词表里的原词**。
4. 审计脚本上线前**必须造已知答案的坏样本先验证它自己** ——
   本次就靠 bad1/bad2 抓出校验器自身 3 个 bug（毫秒换算、格式误判、切片越界）。

### 本项目配套
审计脚本：`保洁/_h3_audit.py`
```bash
"$PY" _h3_audit.py xs900_segs/seg01_prompt.txt xs001_segs/seg02_prompt.txt
```
覆盖：六段齐全与顺序、正文/总词数、镜头数、Shot1无时间戳、切点递增与格式、
每刀带时间戳、运镜类型+幅度+速度齐全、retention 标记、无 (Sx) 混入 retention、
台词未加引号、non_diegetic_music、否定词/对称词、胸前文字。
