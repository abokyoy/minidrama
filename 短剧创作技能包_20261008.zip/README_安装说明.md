# 短剧创作技能包 · 安装说明

打包日：2026-10-08来源：`~/.workbuddy/skills/short-drama-creation/`

---

## 一、包里有什么

```
短剧技能包/
├── short-drama-creation/          ★ 主 skill（16 个文件）
│   ├── SKILL.md                    ← 入口，从这个文件读起
│   ├── references/                ← 10 个分册，按需查阅
│   │   ├── 01-立项与设定.md            题材七问 / 设定三问 / 反派四层 / 红线
│   │   ├── 02-三线契约与分集.md        长中短线 / 每集四栏 / 爽点四要素 / 欠账台账
│   │   ├── 03-评审门.md               五维重判表 / 三毒素 / 三道交付门
│   │   ├── 04-文字剧本与连续脚本.md    补六类信息 / 顺接测试三用例
│   │   ├── 05-分镜与生成.md           beats 写法 / H3 六段式 / 体检清单
│   │   ├── 06-市场调研与热点对标.md★ 番茄红果榜单怎么抓怎么用
│   │   ├── 07-客群投票门.md           ★ JEV 三原语 / 分群面板 / 90% 过门线 / 三坑
│   │   ├── 模式库.md                  ★ 6 张已验证卡 + 5 张已验证失败卡 + 10 骨架
│   │   ├── 去AI味.md                   ★ 三层检测 / X002 风格裁决 7 条
│   │   └── 已知未知.md                 ★ 角色卡三字段 / 逐镜信息差
│   └── templates/                  ← 5 套可直接套用的空模板
│       ├── 立项卡模板.md
│       ├── 三线契约表模板.md
│       ├── 连续脚本表模板.md
│       ├── 投票记录模板.md
│       └── beats模板.json
│
├── related-skills/                ← 主 skill 会引用，建议一起装
│   ├── minimax-h3-prompt-guide/       H3 六段式官方规范全套
│   ├── minimax-h3-prompt-audio/台词说人话 / 唱对词
│   ├── minimax-h3-chained-segment-drift/ 分段续接掉色诊断
│   └── typesafe-ai/                   JEV API 文档（客群投票用）
│
├── scripts/                       ← 零 Token 校验脚本
│   ├── _ai_taste.py                   去 AI 味检测
│   ├── _ai_taste_selfcheck.py         ⛔ 校验器自检样本
│   └── _h3_audit.py                   H3 提示词 24 项审计
│
└── 项目规范/
    └── AGENTS_短剧版.md               项目级工作原则（七条铁律）
```

---

## 二、怎么装

### 装法 A · 拷贝到 skills 目录（推荐）

把 `short-drama-creation/` 和 `related-skills/` 下四个目录**整个拷进**目标 agent 的skills 目录：

```
~/.workbuddy/skills/          # Windows: %USERPROFILE%\.workbuddy\skills\
├── short-drama-creation/
├── minimax-h3-prompt-guide/
├── minimax-h3-prompt-audio/
├── minimax-h3-chained-segment-drift/
└── typesafe-ai/
```

### 装法 B · 只装主 skill

只拷 `short-drama-creation/`。方法论完整可用，只是 H3 提示词细节和 JEV API 要另外找。

---

## 三、怎么用

### 触发方式

主 skill 靠 description 自动触发。跟 agent 说下面任何一句就会加载：

- 「写个短剧」
- 「按 short-drama-creation 走」
- 「我要做竖屏爽剧 / 悬疑短剧 / 修仙剧」
- 「拆戏成分镜」

### 显式加载

```
Skill(skill="short-drama-creation")
```

---

## 四、⚠️ 换环境必改的三处

方法论是通用的，但下面三处**带本机/ 本项目痕迹**，换环境要先改：

### 1. 脚本路径

`scripts/` 下的脚本假定自己躺在项目的 `保洁/` 目录里。放到新环境后改这一行：

```python
BASE = os.path.dirname(os.path.abspath(__file__))
# 若脚本与剧本不在同一目录树，改成剧本所在的项目根
```

### 2. Python 解释器

脚本用 **Python 3.13+**，且需要预装：`opencv-python`、`numpy`、`requests`。

### 3. 05-分镜与生成.md 里的环境参数

该分册含本机实测数据（ComfyUI 端口、VAE 档位、显存要求），换机器要重测：

| 项 | 本机实测值 |
|---|---|
| ComfyUI 实例端口 | 8189 |
| GPU | RTX 3080Ti 16GB，**必须 --lowvram** |
| 画幅 | 9:16 竖屏 |
| 上线画质档 | `hd_turbo8`（VAE 必须 int8） |
| 提示词正文上限 | 350–500 英文词 |

---

## 五、⚠️ 没打进包里的东西（重要）

以下是本项目资产，**体积大且含X003 专用硬编码**，没放进方法论包：

| 没打的 | 原因 |
|---|---|
| `storyboard_render.py`（102KB） | 硬编码了 X003 的楼名/ 场次映射 / 90 处项目名词，换项目要改|
| `check_beats.py` / `_dup_check.py` | 绑定本项目目录结构 |
| `终版剧本/` 三部剧原文 | 项目资产，不是工具 |
| `保洁/ep00N_beats/` 分镜 JSON | 同上 |
| 角色设定图 `assets_single/` | 同上 |
| `保洁/*.py` 其余生成器脚本 | 绑定本机 ComfyUI 路径 |

**如果新agent 需要渲染分镜**，把 `storyboard_render.py` 单独拿过去，改掉里面的项目名词（搜 `万山` / `景宸` / 角色名）即可。

---

## 六、方法论核心（10 秒读完）

### 十阶段流水线
```
市场调研 → 立项 → 设定 → ★投票门A → 契约 → 评审门
        → 文字剧本 → ★投票门B → 连续脚本 → 分镜 → 成片体检
```
每一阶段有门禁，门禁不过不许进下一阶段。

⛔ **顺序不可倒。** 最常见的死法是「先写分镜，回头补剧本」——
这样写出来的镜头之间人物位置必然跳变。

⛔ **两条门禁不能互相替代**：投票门判「观众喜不喜欢」，评审门判「结构对不对」。

### 七条铁律
1. **空间连续性** —— 抄上一镜站位原文逐字对照
2. **代价式战果** —— 赢必须当场付代价
3. **对手不降智** —— 反派每 10 集一次有效进攻
4. **不做闭门创作** —— 立项前必看番茄/红果榜单，留抓取日期
5. **客群投票不取平均** —— 任一分群留看 ≥90% 才过门
6. **爽点必须先挑卡** —— 去模式库，不许临场想
7. **反派降智多半是信息差问题** —— 角色卡填已知/未知/认知边界

---

## 七、校验命令

```bash
PY="C:/Users/86134/.workbuddy/binaries/python/envs/default/Scripts/python.exe"

# 去 AI 味检测（≥70 block / 40-69 warn / <40 pass）
"$PY" scripts/_ai_taste.py <剧本文件.md>

# ⛔ 改过 _ai_taste.py 后必跑，验证校验器自己没被削弱
"$PY" scripts/_ai_taste_selfcheck.py

# H3 提示词审计
"$PY" scripts/_h3_audit.py <segNN_prompt.txt>
```

⛔ **改任何校验脚本后，必须先跑它的自检样本。校验器本身也会骗人。**
